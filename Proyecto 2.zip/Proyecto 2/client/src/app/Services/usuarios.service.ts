import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UsuarioInterface } from '../Models/usuarioInterface';

@Injectable({
  providedIn: 'root'
})
export class UsuariosService {

  API_URI = 'http://localhost:3000/usuarios';

  constructor(private http: HttpClient) { }

  headers: HttpHeaders = new HttpHeaders({
    "Content-Type":"application/json"
  })

  cargarDatosUsuarios(): any{
    return this.http.get(`${this.API_URI}/todos`);
  }

  setUsuarioActual(usuario: UsuarioInterface){
    let username_string = JSON.stringify(usuario);
    localStorage.setItem('UsuarioLogeado', username_string);
  }

  getUsuarioActual(){
    let usesrnameActual = localStorage.getItem('UsuarioLogeado');
    if (usesrnameActual){
      let username_json = JSON.parse(usesrnameActual);
      return username_json;
    }else{
      return null;
    }
  }

  eliminarUsuarioActual(){
    localStorage.removeItem('UsuarioLogeado');
  }

}
