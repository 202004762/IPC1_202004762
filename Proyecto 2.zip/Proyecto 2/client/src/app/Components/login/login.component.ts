import { Component, OnInit } from '@angular/core';
import { UsuarioInterface } from 'src/app/Models/usuarioInterface';
import { UsuariosService } from 'src/app/Services/usuarios.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  nombreUsuario: string = "";
  contrasenaUsuario: string = "";
  datosUsuarios: UsuarioInterface[] = [];

  constructor(private usuarioService: UsuariosService, public router: Router) { }

  ngOnInit(): void {
    this.CargarDatos();
  }

  CargarDatos(){
    this.usuarioService.cargarDatosUsuarios().subscribe(async (res) => {
      let datos: any = res;
      this.datosUsuarios = datos;
      //console.log("LISTADO DE USUARIOS");
      //console.log(this.datosUsuarios);
    },
    err => console.log(err));
  }

  login(){
    if(this.nombreUsuario!= "" && this.contrasenaUsuario != ""){
      for (const usuario of this.datosUsuarios) {
        if(usuario.Usuario == this.nombreUsuario && usuario.Password == this.contrasenaUsuario){
          this.usuarioService.setUsuarioActual(usuario);
          this.router.navigate(['/paginaPrincipal']);
          break;
        }
      }
    }else{
      
    }
    console.log(this.nombreUsuario);
    console.log(this.contrasenaUsuario);
  }

}
