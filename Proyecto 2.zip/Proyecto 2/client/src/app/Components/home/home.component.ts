import { Component, OnInit } from '@angular/core';
import { JugadorService } from 'src/app/Services/jugador.service';
import { JugadorInterface } from 'src/app/Models/jugadorInterface';
import { UsuarioInterface } from 'src/app/Models/usuarioInterface';
import { UsuariosService } from 'src/app/Services/usuarios.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  DatosJugadores: JugadorInterface[]=[];
  usuario: UsuarioInterface;

  constructor(public jugadorService: JugadorService, private usuarioService: UsuariosService) { }

  ngOnInit(): void {
    this.obtenerJugadores();
    this.ObtenerDatosUsuarioLog();
  }

  ObtenerDatosUsuarioLog(){
    this.usuario = this.usuarioService.getUsuarioActual();
  }

  obtenerJugadores(){
    this.jugadorService.cargarDatos().subscribe(async (res) => {
      let datos: any=res;
      this.DatosJugadores=datos;
      console.log("LISTADO DE JUGADORES");
      console.log(this.DatosJugadores);
    },
    err=>console.log(err));
  }

}
