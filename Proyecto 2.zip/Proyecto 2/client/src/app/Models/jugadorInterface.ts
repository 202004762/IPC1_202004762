export interface JugadorInterface{
    id: number;
    nombre: string;
    apellido: string;
    seleccion: string;
    region: string;
    imagen: string;
}