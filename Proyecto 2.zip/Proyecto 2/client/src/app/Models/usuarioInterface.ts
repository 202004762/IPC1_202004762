export interface UsuarioInterface{
    Usuario: string,
    Password: string
}